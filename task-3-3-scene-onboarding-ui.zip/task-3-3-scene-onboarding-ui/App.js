import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Animated, { FadeIn, FadeOut, SlideInLeft, SlideOutRight } from 'react-native-reanimated';

const Stack = createStackNavigator();

const OnboardingScreen = ({ navigation }) => {
  const [currentScreen, setCurrentScreen] = useState(0);

  const screens = [
    {
      icon: '🌟',
      title: 'Welcome',
      description: 'Discover amazing features and tools to make your life easier.',
    },
    {
      icon: '🚀',
      title: 'Get Started',
      description: 'Start your journey with us and explore endless possibilities.',
    },
    {
      icon: '🎉',
      title: 'Enjoy',
      description: 'Enjoy a seamless experience tailored just for you.',
    },
  ];

  const handleNext = () => {
    if (currentScreen < screens.length - 1) {
      setCurrentScreen(currentScreen + 1);
    } else {
      navigation.navigate('Home'); // Navigate to the main app screen
    }
  };

  return (
    <View style={styles.container}>
      <Animated.View
        key={currentScreen}
        entering={FadeIn.duration(500)}
        exiting={FadeOut.duration(500)}
        style={styles.content}
      >
        <Text style={styles.icon}>{screens[currentScreen].icon}</Text>
        <Text style={styles.title}>{screens[currentScreen].title}</Text>
        <Text style={styles.description}>{screens[currentScreen].description}</Text>
      </Animated.View>

      <TouchableOpacity style={styles.button} onPress={handleNext}>
        <Text style={styles.buttonText}>
          {currentScreen === screens.length - 1 ? 'Get Started' : 'Next'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const HomeScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>Welcome to the App!</Text>
  </View>
);

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Onboarding" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  content: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  icon: {
    fontSize: 80,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    color: '#666',
  },
  button: {
    position: 'absolute',
    bottom: 50,
    backgroundColor: '#6200ee',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 25,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default App;