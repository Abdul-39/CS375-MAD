import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";

const ProfileCard = () => {
  const [isFollowing, setIsFollowing] = useState(false);

  return (
    <View style={styles.card}>
      <Image
        source={{ uri: "https://randomuser.me/api/portraits/men/1.jpg" }}
        style={styles.profileImage}
      />
      <Text style={styles.name}>Abdul Rehman</Text>
      <Text style={styles.bio}>Student of BSCS at Abasyn University</Text>
      <TouchableOpacity
        style={[styles.button, isFollowing ? styles.following : styles.follow]}
        onPress={() => setIsFollowing(!isFollowing)}
      >
        <Text style={styles.buttonText}>{isFollowing ? "Following" : "Follow"}</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 25,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 6,
    elevation: 8,
    margin: 25,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 15,
    borderWidth: 3,
    borderColor: "#007bff",
  },
  name: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 8,
    color: "#333",
  },
  bio: {
    fontSize: 16,
    color: "#666",
    marginBottom: 20,
    textAlign: "center",
    paddingHorizontal: 10,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 8,
  },
  follow: {
    backgroundColor: "#007bff",
  },
  following: {
    backgroundColor: "#28a745",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});

export default ProfileCard;
