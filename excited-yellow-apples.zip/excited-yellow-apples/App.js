import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Switch } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';

export default function App() {
    const [isPortrait, setIsPortrait] = useState(true);
    const [lockScreen, setLockScreen] = useState(false);

    useEffect(() => {
        const lockOrientation = async () => {
            try {
                if (lockScreen) {
                    // Completely lock to current state (prevent user rotation)
                    await ScreenOrientation.lockAsync(
                        isPortrait
                            ? ScreenOrientation.OrientationLock.PORTRAIT_UP
                            : ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT
                    );
                } else {
                    // Allow user to toggle orientation
                    await ScreenOrientation.unlockAsync();
                }
            } catch (error) {
                console.error('Error changing orientation:', error);
            }
        };

        lockOrientation();

        // Prevent user from rotating manually
        const preventRotation = () => {
            if (lockScreen) {
                ScreenOrientation.lockAsync(
                    isPortrait
                        ? ScreenOrientation.OrientationLock.PORTRAIT_UP
                        : ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT
                );
            }
        };

        const subscription = ScreenOrientation.addOrientationChangeListener(preventRotation);

        return () => {
            ScreenOrientation.removeOrientationChangeListener(subscription);
        };
    }, [isPortrait, lockScreen]);

    const toggleOrientation = () => {
        if (!lockScreen) {
            setIsPortrait(!isPortrait);
        }
    };

    const toggleLockScreen = () => {
        setLockScreen(!lockScreen);
    };

    return (
        <View style={[styles.container, isPortrait ? styles.portrait : styles.landscape]}>
            <Text style={styles.text}>
                Current Orientation: {isPortrait ? '📱 Portrait' : '📺 Landscape'}
            </Text>

            <TouchableOpacity 
                style={[styles.button, lockScreen && styles.disabledButton]} 
                onPress={toggleOrientation}
                disabled={lockScreen}
            >
                <Text style={styles.buttonText}>Flip Orientation</Text>
            </TouchableOpacity>

            <View style={styles.switchContainer}>
                <Text style={styles.switchLabel}>
                    {lockScreen ? '🔒 Locked' : '🔓 Unlocked'}
                </Text>
                <Switch 
                    value={lockScreen} 
                    onValueChange={toggleLockScreen} 
                    trackColor={{ false: "#767577", true: "#34C759" }}
                    thumbColor={lockScreen ? "#FFF" : "#F4F3F4"}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    portrait: {
        backgroundColor: '#f8f9fa',
    },
    landscape: {
        backgroundColor: '#a3d2fc',
    },
    text: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    button: {
        padding: 12,
        borderRadius: 8,
        width: 200,
        alignItems: 'center',
        marginBottom: 10,
        backgroundColor: '#007BFF',
    },
    disabledButton: {
        backgroundColor: '#B0B0B0',
    },
    buttonText: {
        color: '#FFFFFF',
        fontSize: 18,
        fontWeight: '600',
    },
    switchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 20,
    },
    switchLabel: {
        fontSize: 18,
        marginRight: 10,
    },
});
