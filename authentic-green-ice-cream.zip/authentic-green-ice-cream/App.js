import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, FlatList, StyleSheet, TouchableOpacity, Image, Text, ScrollView } from 'react-native';
import { Searchbar, Button, FAB } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { LinearGradient } from 'expo-linear-gradient'; // Updated import for Expo

// Dummy Data
const products = [
  { id: '1', name: 'Product 1', price: '$20', image: 'https://via.placeholder.com/150' },
  { id: '2', name: 'Product 2', price: '$30', image: 'https://via.placeholder.com/150' },
  { id: '3', name: 'Product 3', price: '$40', image: 'https://via.placeholder.com/150' },
];

const cartItems = [
  { id: '1', name: 'Product 1', price: '$20', quantity: 1 },
  { id: '2', name: 'Product 2', price: '$30', quantity: 2 },
];

// Home Screen
function HomeScreen({ navigation }) {
  const [searchQuery, setSearchQuery] = React.useState('');

  const renderProduct = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('ProductDetails', { product: item })}>
      <View style={styles.productCard}>
        <LinearGradient colors={['#6a11cb', '#2575fc']} style={styles.gradient}>
          <Image source={{ uri: item.image }} style={styles.productImage} />
          <View style={styles.productDetails}>
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>{item.price}</Text>
          </View>
        </LinearGradient>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Search products"
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchBar}
      />
      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.productList}
      />
      <FAB
        style={styles.fab}
        icon="cart"
        onPress={() => navigation.navigate('Cart')}
      />
    </View>
  );
}

// Product Details Screen
function ProductDetailsScreen({ route, navigation }) {
  const { product } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: product.image }} style={styles.productImageLarge} />
      <View style={styles.detailsContainer}>
        <Text style={styles.productNameLarge}>{product.name}</Text>
        <Text style={styles.productPriceLarge}>{product.price}</Text>
        <Text style={styles.productDescription}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </Text>
        <Button
          mode="contained"
          onPress={() => navigation.navigate('Cart')}
          style={styles.addToCartButton}
          labelStyle={styles.buttonLabel}
        >
          Add to Cart
        </Button>
      </View>
    </ScrollView>
  );
}

// Cart Screen
function CartScreen() {
  const totalPrice = cartItems.reduce((sum, item) => sum + parseFloat(item.price.replace('$', '')) * item.quantity, 0);
  const [items, setItems] = React.useState(cartItems);

  const removeItem = (id) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const renderCartItem = ({ item }) => (
    <View style={styles.cartItem}>
      <Image source={{ uri: 'https://via.placeholder.com/150' }} style={styles.cartItemImage} />
      <View style={styles.cartItemDetails}>
        <Text style={styles.cartItemName}>{item.name}</Text>
        <Text style={styles.cartItemPrice}>{item.price} x {item.quantity}</Text>
      </View>
      <TouchableOpacity onPress={() => removeItem(item.id)} style={styles.removeButton}>
        <Icon name="delete" size={24} color="#ff4444" />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={items}
        renderItem={renderCartItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.cartList}
      />
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>Total: ${totalPrice.toFixed(2)}</Text>
        <Button
          mode="contained"
          onPress={() => alert('Proceed to Checkout')}
          style={styles.checkoutButton}
          labelStyle={styles.buttonLabel}
        >
          Checkout
        </Button>
      </View>
    </View>
  );
}

// Navigation Setup
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ProductDetails" component={ProductDetailsScreen} />
        <Stack.Screen name="Cart" component={CartScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  searchBar: {
    marginBottom: 16,
    borderRadius: 10,
    elevation: 3,
  },
  productList: {
    justifyContent: 'space-between',
  },
  productCard: {
    flex: 1,
    margin: 8,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 5,
  },
  gradient: {
    padding: 16,
    alignItems: 'center',
  },
  productImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  productDetails: {
    marginTop: 8,
    alignItems: 'center',
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  productPrice: {
    fontSize: 14,
    color: '#fff',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#6a11cb',
  },
  productImageLarge: {
    width: '100%',
    height: 300,
  },
  detailsContainer: {
    padding: 16,
  },
  productNameLarge: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  productPriceLarge: {
    fontSize: 20,
    color: '#6a11cb',
    marginVertical: 8,
  },
  productDescription: {
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
  },
  addToCartButton: {
    marginTop: 16,
    borderRadius: 10,
    backgroundColor: '#6a11cb',
  },
  buttonLabel: {
    color: '#fff',
  },
  cartItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    marginBottom: 8,
    elevation: 3,
  },
  cartItemImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
  },
  cartItemDetails: {
    flex: 1,
    marginLeft: 16,
  },
  cartItemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  cartItemPrice: {
    fontSize: 14,
    color: '#666',
  },
  removeButton: {
    padding: 8,
  },
  totalContainer: {
    marginTop: 16,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  checkoutButton: {
    marginTop: 8,
    borderRadius: 10,
    backgroundColor: '#6a11cb',
  },
});